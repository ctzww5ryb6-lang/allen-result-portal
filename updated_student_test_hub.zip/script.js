// Demo result records used by this student project.
const results = {
    "2460638731": {
        name: "Harshit Kumar",
        test: "Minor Test CBT Mode",
        testDate: "21 Nov, 2026",
        physics: 138,
        chemistry: 150,
        biology: 310
    },

    "123456": {
        name: "Sakshi Priyashi",
        test: "Practice Test 01",
        testDate: "Date not provided",
        physics: 120,
        chemistry: 145,
        biology: 320
    },

    "2461004056": {
        name: "Divyanshu Kiahan",
        test: "Practice Test 02",
        testDate: "Date not provided",
        physics: 160,
        chemistry: 150,
        biology: 325
    }
};

function showResult() {
    const formId = document.getElementById("formId")
        .value
        .trim()
        .toUpperCase();

    displayResult(formId);
}

function displayResult(formId) {
    const error = document.getElementById("error");
    const result = document.getElementById("result");

    if (!results[formId]) {
        result.style.display = "none";
        error.textContent = "No demo result found for this Form ID. Please check and try again.";
        return;
    }

    const student = results[formId];

    const total = student.physics + student.chemistry + student.biology;
    const percentage = ((total / 720) * 100).toFixed(2);

    document.getElementById("studentName").textContent = student.name;
    document.getElementById("studentId").textContent = formId;
    document.getElementById("testName").textContent = student.test || "Test details unavailable";
    document.getElementById("testDate").textContent = student.testDate || "Date not provided";

    document.getElementById("physics").textContent = student.physics;
    document.getElementById("chemistry").textContent = student.chemistry;
    document.getElementById("biology").textContent = student.biology;

    document.getElementById("total").textContent = total;
    document.getElementById("percentage").textContent = percentage + "%";

    const physicsPercent = (student.physics / 180) * 100;
    const chemistryPercent = (student.chemistry / 180) * 100;
    const biologyPercent = (student.biology / 360) * 100;

    document.getElementById("physicsBar").style.width = physicsPercent + "%";
    document.getElementById("chemistryBar").style.width = chemistryPercent + "%";
    document.getElementById("biologyBar").style.width = biologyPercent + "%";

    document.getElementById("physicsPercent").textContent = physicsPercent.toFixed(1) + "%";
    document.getElementById("chemistryPercent").textContent = chemistryPercent.toFixed(1) + "%";
    document.getElementById("biologyPercent").textContent = biologyPercent.toFixed(1) + "%";

    error.textContent = "";
    result.style.display = "block";
    result.scrollIntoView({ behavior: "smooth", block: "start" });
}

// Check Form ID from URL, for example: ?id=2460638731
const params = new URLSearchParams(window.location.search);
const urlFormId = params.get("id");

if (urlFormId) {
    const formId = urlFormId.trim().toUpperCase();
    document.getElementById("formId").value = formId;
    displayResult(formId);
}
